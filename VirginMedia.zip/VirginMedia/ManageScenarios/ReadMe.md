

There are three projects in the solutions, and all are using .net 5 framework.

To Run the application , Web api and Web app should run together or Web api should run first.

When run the web app, it loads the home page, click on the Scenario link in the top navigation to go into the scenario listing.