using AutoMapper;
using ManageScenarios.Api.Controllers;
using ManageScenarios.Api.Dtos;
using ManageScenarios.Api.Entities;
using ManageScenarios.Api.Helpers;
using ManageScenarios.Api.ResourceParameters;
using ManageScenarios.Api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace ManageScenarios.Api.UnitTest
{
    public class ScenariosControllerTest
    {

        private Mock<ISenarioService> _scenarioService;
        private Mock<IMapper> _mapper;
        private Mock<ILogger<ScenariosController>> _logger;


        public ScenariosControllerTest()
        {
            _scenarioService = new Mock<ISenarioService>();
            _mapper = new Mock<IMapper>();
            _logger = new Mock<ILogger<ScenariosController>>();
        }

        [Fact]
        public async Task GetScenariosWithNullReponse_ReturnedNotFound()
        {
            // Arr
            var request = new ScenariosResourceParameters { PageNumber = 100, PageSize = 10 };
            var scenariosController = new ScenariosController(_scenarioService.Object, _mapper.Object, _logger.Object);
            _scenarioService.Setup(a => a.GetScenariosAsync(request.PageNumber, request.PageSize, It.IsAny<CancellationToken>()))
                .ReturnsAsync(It.IsAny<PagedList<Scenario>>());

            // Act
            var result = await scenariosController.GetScenarios(request);

            // Assert
            _scenarioService.Verify(a => a.GetScenariosAsync(request.PageNumber, request.PageSize, It.IsAny<CancellationToken>()), Times.Once);
            Assert.Equal(StatusCodes.Status404NotFound, (result as NotFoundResult).StatusCode);
        }

        [Fact]
        public async Task GetScenariosWithSuccessReponse_ReturnedOK()
        {
            // Arr
            var list = new List<Scenario>
            { 
                new Scenario { Id = 1, Forename = "Mark"}, 
                new Scenario { Id = 2, Forename = "Shantha" }
            };
            var request = new ScenariosResourceParameters { PageNumber = 1, PageSize = 10 };
            var scenariosController = new ScenariosController(_scenarioService.Object, _mapper.Object, _logger.Object);
            var resultList = PagedList<Scenario>.CreateAsync(list,1,1,10);
            _scenarioService.Setup(a => a.GetScenariosAsync(request.PageNumber, request.PageSize, It.IsAny<CancellationToken>()))
                .ReturnsAsync(resultList);

            // Act
            var result = await scenariosController.GetScenarios(request);

            // Assert
            _scenarioService.Verify(a => a.GetScenariosAsync(request.PageNumber, request.PageSize, It.IsAny<CancellationToken>()), Times.Once);
            Assert.Equal(StatusCodes.Status200OK, (result as OkObjectResult).StatusCode);
        }
    }
}
