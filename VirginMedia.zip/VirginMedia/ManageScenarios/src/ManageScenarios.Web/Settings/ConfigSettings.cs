﻿namespace ManageScenarios.Web.Settings
{
    public class ConfigSettings
    {
        public string ScenarioBaseApi { get; set; }
        public int ScenarioListSize { get; set; }
    }
}
