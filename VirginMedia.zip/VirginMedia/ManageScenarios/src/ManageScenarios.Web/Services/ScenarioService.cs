﻿using ManageScenarios.Web.Helpers;
using ManageScenarios.Web.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace ManageScenarios.Web.Services
{
    public class ScenarioService : IScenarioService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<ScenarioService> _logger;

        public ScenarioService(HttpClient httpClient, ILogger<ScenarioService> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }
        public async Task<PaginatedList<Scenario>> GetScenariosAsync(int pageNumber, int pageSize, CancellationToken cancellationToken = default)
        {
            var requestEndpoint = $"/api/scenarios?PageNumber={pageNumber}&PageSize={pageSize}";
            var reply = await _httpClient.GetAsync(requestEndpoint, cancellationToken);
            if (reply.IsSuccessStatusCode)
            {
                var stream = await reply.Content.ReadAsStreamAsync();
                var pagination = JsonConvert.DeserializeObject<PaginationMetaData>(
                    reply.Headers.GetValues("X-Pagination").First());

                using var streamReader = new StreamReader(stream);
                using var jsonTextReader = new JsonTextReader(streamReader);
                var jsonSerializer = new JsonSerializer();
                var scenarios = jsonSerializer.Deserialize<IEnumerable<Scenario>>(jsonTextReader);
                return PaginatedList<Scenario>.CreateAsync(scenarios.ToList(), pagination.totalCount,
                pagination.currentPage, pagination.pageSize);


            }
            _logger.LogError($"nothing returned from api for page number {pageNumber}");
            return null;
        }
    }
}
