﻿using ManageScenarios.Web.Helpers;
using ManageScenarios.Web.Models;
using System.Threading;
using System.Threading.Tasks;

namespace ManageScenarios.Web.Services
{
    public interface IScenarioService
    {
        Task<PaginatedList<Scenario>> GetScenariosAsync(int pageNumber, int pageSize, CancellationToken cancellationToken = default);
    }
}
