﻿using ManageScenarios.Web.Services;
using ManageScenarios.Web.Settings;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

namespace ManageScenarios.Web.Controllers
{
    public class ScenariosController : Controller
    {
        private readonly IScenarioService _scenarioService;
        private readonly ConfigSettings _configSettings;
        private readonly ILogger<ScenariosController> _logger;

        public ScenariosController(IScenarioService scenarioService, IOptions<ConfigSettings> options,
            ILogger<ScenariosController> logger)
        {
            _scenarioService = scenarioService;
            _configSettings = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _logger = logger;
        }
        public async Task<IActionResult> Index(int? pageNumber)
        {
           if (pageNumber == null)
                pageNumber = 1;
            var scenarios = await _scenarioService.GetScenariosAsync(pageNumber.GetValueOrDefault(), _configSettings.ScenarioListSize);

            if (scenarios == null)
                _logger.LogWarning($"page number {pageNumber} has no records to show");

            return View(scenarios);
        }
    }
}
