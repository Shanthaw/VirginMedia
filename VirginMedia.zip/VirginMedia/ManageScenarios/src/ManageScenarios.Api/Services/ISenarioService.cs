﻿using ManageScenarios.Api.Entities;
using ManageScenarios.Api.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ManageScenarios.Api.Services
{
    public interface ISenarioService
    {
        Task<PagedList<Scenario>> GetScenariosAsync(int pageNumber, int pageSize, CancellationToken cancellationToken = default);
    }
}
