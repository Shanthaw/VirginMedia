﻿using AutoMapper;
using ManageScenarios.Api.Dtos;
using ManageScenarios.Api.ResourceParameters;
using ManageScenarios.Api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace ManageScenarios.Api.Controllers
{
    [Route("api/scenarios")]
    [ApiController]
    public class ScenariosController : ControllerBase
    {
        private readonly ISenarioService _senarioService;
        private readonly IMapper _mapper;
        private readonly ILogger<ScenariosController> _logger;

        public ScenariosController(ISenarioService senarioService,IMapper mapper, ILogger<ScenariosController> logger)
        {
            _senarioService = senarioService;
            _mapper = mapper;
            _logger = logger;
        }
        [HttpGet(Name = "GetScenarios")]
        public async Task<IActionResult> GetScenarios([FromQuery] ScenariosResourceParameters resourceParameters)
        {

            var results = await _senarioService.GetScenariosAsync(resourceParameters.PageNumber, resourceParameters.PageSize);

            if (results != null && results.Count > 0)
            {
                var paginationMetadata = new
                {
                    totalCount = results.TotalCount,
                    pageSize = results.PageSize,
                    currentPage = results.CurrentPage,
                    totalPages = results.TotalPages

                };
                if(Response != null)
                {
                    Response.Headers.Add("X-Pagination",
                   JsonSerializer.Serialize(paginationMetadata));
                }

                return Ok(_mapper.Map<IEnumerable<ScenarioDto>>(results));
            }
            return NotFound();

        }



    }
}
