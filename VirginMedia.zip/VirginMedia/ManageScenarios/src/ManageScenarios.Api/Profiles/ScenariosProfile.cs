﻿using AutoMapper;
using ManageScenarios.Api.Dtos;
using ManageScenarios.Api.Entities;

namespace ManageScenarios.Api.Profiles
{
    public class ScenariosProfile:Profile
    {
        public ScenariosProfile()
        {
            CreateMap<Scenario, ScenarioDto>();
        }
    }
}
