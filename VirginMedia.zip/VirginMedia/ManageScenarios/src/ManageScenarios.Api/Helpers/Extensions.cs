﻿using System;
using System.Xml.Linq;

namespace ManageScenarios.Api.Helpers
{
    public static class Extensions
    {

        public static DateTime ToDateTime(this XElement xEleDateTime)
        {
            if (xEleDateTime == null)
                return DateTime.MinValue;
            var strDateTime = xEleDateTime.Value;
            strDateTime = strDateTime.Replace(" ", "");
            DateTime.TryParseExact(strDateTime, "yyyy-MM-ddTHH:mm:ss", null, System.Globalization.DateTimeStyles.None,out DateTime res);
            return res;
        }
        public static int ToInt(this XElement xEleInt)
        {
            _ = int.TryParse(xEleInt?.Value, out int o);
            return o;
        }
    }
}
