﻿using ManageScenarios.Api.Entities;
using ManageScenarios.Api.Helpers;
using ManageScenarios.Api.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ManageScenarios.Api.Infrastructure
{
    public class XmlSenariosDataService : ISenarioService
    {
        private readonly string _path;

        public XmlSenariosDataService(string path)
        {
            if (!File.Exists(path)) throw new FileNotFoundException(nameof(_path));
            _path = path;
        }
        public async Task<PagedList<Scenario>> GetScenariosAsync(int pageNumber, int pageSize, CancellationToken cancellationToken = default)
        {
            var doc = await LoadAsync();
            var count = doc.Descendants("Scenario").Count();
            var scenarios = from s in doc.Descendants("Scenario").Skip((pageNumber - 1) * pageSize).Take(pageSize)
                            select new Scenario
                            {
                                Id = s.Element("ScenarioID").ToInt(),
                                Name = s.Element("Name")?.Value,
                                Surname = s.Element("Surname")?.Value,
                                Forename = s.Element("Forename")?.Value,
                                UserId = s.Element("UserID")?.Value,
                                SampleDate = s.Element("SampleDate").ToDateTime(),
                                CreationDate = s.Element("CreationDate").ToDateTime(),
                                NumMonths = s.Element("NumMonths").ToInt(),
                                MarketId = s.Element("MarketID").ToInt(),
                                NetworkLayerId = s.Element("NetworkLayerID").ToInt()

                            };
            return PagedList<Scenario>.CreateAsync(scenarios, count, pageNumber, pageSize);
        }

        public Task<XDocument> LoadAsync()
        {
            return Task.Run(() =>
            {
                   using var stream = File.OpenText(_path);
                    return XDocument.Load(stream, LoadOptions.PreserveWhitespace);
            });
        }
    }
}
